<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script setup>
</script>

<style scoped>
#app {
  font-family: "Arial", sans-serif;
  background-color: #064968c4;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>